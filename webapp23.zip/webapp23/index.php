<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.jpg" />
        <title>Habesha culture</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
       
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
      
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <body>
        <div>
           <?php
            require 'header.php';
           ?>
           <div id="bannerImage">
               <div class="container">
                   <center>
                   <div id="bannerContent">
                       <h1>We sell .</h1>
                       <p>40% OFF on all products.</p>
                       <a href="products.php" class="btn btn-danger">Shop Now</a>
                   </div>
                   </center>
               </div>
           </div>
           <div class="container">
               <div class="row">
                   <div class="col-xs-4">
                       <div  class="thumbnail">
                           <a href="products.php">
                                <img src="img/dress1.jpg" alt="dress">
                           </a>
                           <center>
                                <div class="caption">
                                        <p id="autoResize">Cultural Dress</p>
                                        <p>Choose among the best available in the world.</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="shoes.php">
                               <img src="img/shoes1.jpg" alt="shoes">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">cultural shoes</p>
                                    <p>Original shoes from the origin.</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="foods.php">
                               <img src="img/food1.jpg" alt="food">
                           </a>
                           <center>
                               <div class="caption">
                                   <p id="autoResize">Foods</p>
                                   <p>Our Fresh Foods.</p>
                               </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="music.php">
                               <img src="img/music1.jpg" alt="music">
                           </a>
                           <center>
                               <div class="caption">
                                   <p id="autoResize">music Instruments</p>
                                   <p>Our Traditional music Instruments.</p>
                               </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="dec.php">
                               <img src="img/dec1.jpg" alt="decor">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">Home Decoration</p>
                                    <p>Our unique Decorations.</p>
                                </div>
                           </center>
                       </div>
                   </div>
                   <div class="col-xs-4">
                       <div class="thumbnail">
                           <a href="kit.php">
                               <img src="img/kit1.jpg" alt="kitchen">
                           </a>
                           <center>
                                <div class="caption">
                                    <p id="autoResize">Kitchen Material</p>
                                    <p>Our Traditional kitchen Materials.</p>
                                </div>
                           </center>
                       </div>
                   </div>
               </div>
           </div>
            
          
    </body>
</html>
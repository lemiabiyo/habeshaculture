<?php
    require 'connection.php';
    session_start();
    $name=$_POST['name'];
    $price=$_SESSION['price'];
    $add_to_item_query="INSERT INTO items(name,price) values ('$name','$price')";
    $add_to_item_result=mysqli_query($con,$add_to_item_query) or die(mysqli_error($con));
    header('location: cart.php');
?>
    